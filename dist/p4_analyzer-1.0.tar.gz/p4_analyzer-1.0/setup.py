#!/usr/bin/env python
# -*-encoding: utf-8-*-

from distutils.core import setup

setup(name='p4_analyzer',
      version='1.0',
      scripts='p4_analyzer')
